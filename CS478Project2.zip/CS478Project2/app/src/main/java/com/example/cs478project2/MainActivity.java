package com.example.cs478project2;

import androidx.appcompat.app.AppCompatActivity;

import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListView;
import android.content.Intent;
import android.os.Bundle;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

import android.widget.PopupMenu;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    List<phoneData> listPhoneData;
    phoneAdapter adapter;
    ListView listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listPhoneData = new ArrayList<>();
        listPhoneData.add(new phoneData(R.drawable.imag1, "Samsung Galaxy Note10", "6.3-inch, $949.99", "8GB", "256GB", "$949.99", "1440x3040-pixel", "https://www.samsung.com/us/mobile/galaxy-s10/"));
        listPhoneData.add(new phoneData(R.drawable.imag2, "iPhone 11 Pro", "6.5-inch, $999.00", "A13 Bionic chip", "64GB, 256GB, 512GB", "$999, $1149, $1349", "2436x1125-pixel", "https://www.apple.com/"));
        listPhoneData.add(new phoneData(R.drawable.imag3, "iPhone XR Max", "6.5-inch, $599.99","A12 Bionic chip", "64GB, 256GB", "$599, $649", "1792x828-pixel", "https://www.apple.com/"));
        listPhoneData.add(new phoneData(R.drawable.imag4, "Google Pixel 3a XL", "6.0-inch, $479.00","4GB", "64GB", "$479.00", "1080x2160-pixel", "https://store.google.com/product/pixel_3a"));
        listPhoneData.add(new phoneData(R.drawable.imag5, "Samsung Galaxy S10", "6.1-inch, $899.99","8GB", "128GB, 512GB", "$899.99, $1149.99", "1080x2160-pixel", "https://www.samsung.com/us/mobile/galaxy-s10/"));
        listPhoneData.add(new phoneData(R.drawable.imag6, "HTC One U12+", "6.0-inch, $649.00","6GB", "64GB, 128GB", "$649.00, $749.00", "2880x1440-pixel", "https://www.htc.com/us/smartphones/htc-u12-plus/"));
        listPhoneData.add(new phoneData(R.drawable.imag7, "Samsung Galaxy Fold", "7.3/4.6-inch, $1979.99","12GB", "512GB", "$1979.99", "2152x1536-pixel", "https://www.samsung.com/global/galaxy/galaxy-fold/"));
        listPhoneData.add(new phoneData(R.drawable.imag8, "iPhone 6", "4.7-inch, $119.99", "A8 Bionic chip", "64GB", "$119.99", "1334x750-pixel", "https://www.apple.com/"));

        listview = (ListView) findViewById(R.id.phonePictureList);
        adapter = new phoneAdapter(this, R.layout.photolist_view, listPhoneData);

        listview.setAdapter(adapter);
        /* Menu for the phones */
        registerForContextMenu(listview);

        //This will let user click on the photo and it will open a new activity and make the picture much bigger
        listview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent1 = new Intent();
                intent1.putExtra("phone photo", listPhoneData.get(i).resID);
                intent1.putExtra("Brand", listPhoneData.get(i).brand);
                intent1.putExtra("info", listPhoneData.get(i).info);

                intent1.setClass(MainActivity.this, bigPhoto.class);
                startActivity(intent1);
                return true;
            }
        });

    }

    @Override
    public void onCreateContextMenu (ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.photo_menu, menu);
    }


    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this,v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.photo_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {

        AdapterContextMenuInfo info = (AdapterContextMenuInfo) menuItem.getMenuInfo();

        //final ItemClass selItem = (ItemClass)this.getListView().getItemAtPosition(info.position);
        switch (menuItem.getItemId()){
            //third activity for: RAM, storage size, price, etc.
            case R.id.option_1:
                final int[] index = new int[1];
                Toast.makeText(this, "specs clicked", Toast.LENGTH_SHORT).show();

                //final int index = (int) listview.getItemAtPosition(info.position);
                //Intent intent1 = new Intent();
                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        index[0] = i;
                    }
                });
                //finish();
                Intent intent1 = new Intent();
                intent1.putExtra("ram", listPhoneData.get(index[0]).ram);
                intent1.putExtra("storage", listPhoneData.get(index[0]).storage);
                intent1.putExtra("storagePrice", listPhoneData.get(index[0]).storagePrice);
                intent1.putExtra("pixel", listPhoneData.get(index[0]).pixel);
                intent1.setClass(MainActivity.this, Specs.class);
                startActivity(intent1);
                return true;
            //entire picture of device
            case R.id.option_2:
                final int[] index1 = new int[1];
                Toast.makeText(this, "Zoom in clicked", Toast.LENGTH_SHORT).show();

                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        index1[0] = i;
                    }
                });


                Intent intent2 = new Intent(this, bigPhoto.class);
                intent2.putExtra("phone photo", listPhoneData.get(index1[0]).resID);
                intent2.putExtra("Brand", listPhoneData.get(index1[0]).brand);
                intent2.putExtra("info", listPhoneData.get(index1[0]).info);
                startActivity(intent2);
                //finish();
                return true;
            //official page
            case R.id.option_3:
                final int[] index3 = new int[1];
                listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        index3[0] = i;
                    }
                });
                Toast.makeText(this, "Find it...clicked", Toast.LENGTH_SHORT).show();
                String in = listPhoneData.get(index3[0]).website;
                Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(in));
                startActivity(intent);


                return true;
            default :
                return super.onOptionsItemSelected(menuItem);
        }
    }


}
