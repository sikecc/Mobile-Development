package com.example.cs478project2;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import java.util.List;

public class phoneAdapter extends ArrayAdapter<phoneData>{
    Context context;
    int layoutResID;
    List<phoneData> data = null;


    public phoneAdapter(Context context, int resource, List<phoneData> objects) {
        super(context, resource, objects);

        this.layoutResID = resource;
        this.context = context;
        this.data = objects;
    }

    static class containData{
        ImageView phoneView;
        TextView phoneName;
        TextView phoneBrand;
    }

    @Override
    public phoneData getItem(int position){
        return data.get(position);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        containData thisHolder = null;

        if(convertView==null){
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            convertView = inflater.inflate(layoutResID, parent, false);

            thisHolder = new containData();
            thisHolder.phoneView = (ImageView)convertView.findViewById(R.id.imageView);
            thisHolder.phoneName = (TextView)convertView.findViewById(R.id.firstTextView);
            thisHolder.phoneBrand = (TextView)convertView.findViewById(R.id.secondTextView);

            convertView.setTag(thisHolder);
        }
        else{
            thisHolder = (containData)convertView.getTag();
        }

        phoneData dataItem = data.get(position);
        thisHolder.phoneName.setText(dataItem.info);
        thisHolder.phoneBrand.setText(dataItem.brand);
        thisHolder.phoneView.setImageResource(dataItem.resID);

        return convertView;
    }


}
