package com.example.cs478project2;

/* This class helps me put data to display on the listview */
public class phoneData {
    int resID;
    String brand;
    String info;
    String ram;
    String storage;
    String pixel;
    String storagePrice;
    String website;

    public phoneData(int resID, String brand, String info, String ram, String storage, String storagePrice, String pix, String website){
        this.resID = resID;
        this.brand = brand;
        this.info = info;
        this.storage = storage;
        this.storagePrice = storagePrice;
        this.ram = ram;
        this.pixel = pix;
        this.website = website;
    }
    int getResID(){return this.resID;}
    String getName(){return this.info;}
    String getBrand(){return this.brand;}

    /* For the specs */
    String getRam(){
        return this.ram;
    }
    String getStorage(){
        return this.storage;
    }
    String getStoragePrice(){
        return this.storagePrice;
    }
    String getPixel(){
        return this.pixel;
    }

}
