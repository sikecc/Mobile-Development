package com.example.cs478project2;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;

public class bigPhoto extends AppCompatActivity {

    ImageView imag;
    TextView brandInfo;
    TextView phoneInfo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_big_photo);

        imag = (ImageView) findViewById(R.id.imageView2);
        brandInfo = (TextView)findViewById(R.id.brandName);
        phoneInfo = (TextView)findViewById(R.id.phoneName);

        brandInfo.setText(getIntent().getStringExtra("Brand"));
        phoneInfo.setText(getIntent().getStringExtra("info"));
        imag.setImageResource(getIntent().getIntExtra("phone photo", R.drawable.imag1));


    }
}
