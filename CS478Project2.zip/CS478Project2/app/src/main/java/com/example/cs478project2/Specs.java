package com.example.cs478project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Specs extends AppCompatActivity {

    TextView ramInfo;
    TextView storageInfo;
    TextView storagePInfo;
    TextView pixelInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specs);


        ramInfo = (TextView)findViewById(R.id.ram);
        storageInfo = (TextView)findViewById(R.id.storage);
        storagePInfo = (TextView)findViewById(R.id.storageprice);
        pixelInfo = (TextView)findViewById(R.id.pixels);

        ramInfo.setText(getIntent().getStringExtra("ram"));
        storageInfo.setText(getIntent().getStringExtra("storage"));
        storagePInfo.setText(getIntent().getStringExtra("storagePrice"));
        pixelInfo.setText(getIntent().getStringExtra("pixel"));



    }
}
