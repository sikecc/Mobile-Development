package com.example.cs478program1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View.OnKeyListener;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.view.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.content.Intent;
import static java.util.regex.Pattern.compile;

public class readOnly extends AppCompatActivity {

    EditText addressEnter;
    TextView theMainText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_only);

        //find the address, addressEnter, and the mainText by obtaining their id on xml sheet
        final Button newAddress = (Button)findViewById(R.id.startButton);
        theMainText = (TextView)findViewById(R.id.message);
        addressEnter =(EditText)findViewById(R.id.enterText);

        //if the user selects enter on the soft keyboard
        TextView.OnEditorActionListener listener = new TextView.OnEditorActionListener(){
            @Override
            public boolean onEditorAction(TextView exampleView, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    newAddress.performClick();
                    return true;
                }
                return false;
            }
        };
        addressEnter.setOnEditorActionListener(listener);

//        addressEnter.setOnEditorActionListener(new OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
//                if (actionId == EditorInfo.IME_ACTION_DONE && event.getAction() == KeyEvent.ACTION_DOWN) {
//                    //addAddress();
//                    newAddress.performClick();
//                    return true;
//                }
//                return false;
//            }
//        });
        //if the done button is selected
        newAddress.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                addAddress();
            }
        });

    }

    //checks the address string format
    public boolean checkAddress(){
        String address = addressEnter.getText().toString();
        Pattern p = Pattern.compile("\\d+\\s+\\w+\\s+(?:st(?:\\.|reet)?|ave(?:\\.|nue)?|lane|dr(?:\\.|ive)?)", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(address);
        boolean b = m.matches();
        return b;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        //did the request go through to contact application
        if (requestCode == 99) {

            //yes, it did!
            if (resultCode == RESULT_OK) {

                theMainText.setText("User Inputted an Address!");
            }
            else {
                theMainText.setText("No Address!!!");
            }
        }
        //request never went through
        else{
            theMainText.setText("System error...did not recieve request code");
        }
    }
//
//    will add the address
    public void addAddress(){
        boolean checkAddy = checkAddress();
        //returns true or false, then do the following
        if(checkAddy) {
            //if true, will exit the second activity and pass the string
            theMainText.setText("Valid Address!");

            Intent intent = new Intent();
            intent.putExtra("theAddress", addressEnter.getText().toString());
            setResult(RESULT_OK, intent);
            finish();

        }
        else {
            //address failed and will not return the address
            theMainText.setText("Invalid address!");

            Intent intent = new Intent();
            //intent.putExtra("theAddress", addressEnter.getText().toString());
            setResult(RESULT_CANCELED, intent);
            finish();
        }

    }

}
