package com.example.cs478program1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.widget.TextView;

//import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.util.Locale;
import android.net.Uri;

public class MainActivity extends AppCompatActivity {

    String editTextString;
    TextView theMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addressButton = (Button)findViewById(R.id.startButton);
        Button mapButton = (Button)findViewById(R.id.button2);

        theMain = (TextView)findViewById(R.id.textView);
        //ask for the address
        addressButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startNext();
            }
        });
        //start map
        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMap();
            }
        });

    }
    public void startNext(){
        Intent intent = new Intent(this, readOnly.class);
        startActivityForResult(intent, 1);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//checks the request code
        if(requestCode == 1){
            if(resultCode == RESULT_OK) {
                theMain.setText("User Inputted an Address!");
                editTextString = data.getStringExtra("theAddress");
            }
            else {
                theMain.setText("No Address!!!");
            }
        }
        else{
            theMain.setText("System error...did not receive request code");
        }

    }
    //opens the map and looks for the address :)
    public void startMap(){
        //makes sure the address is not empty
        if(!editTextString.isEmpty()){
            String uri = String.format(Locale.ENGLISH, "geo:0,0?q="+editTextString);
            Intent i = new Intent(android.content.Intent.ACTION_VIEW,Uri.parse(uri));
            i.setClassName("com.google.android.apps.maps",
                    "com.google.android.maps.MapsActivity");
            startActivity(i);
        }
        else{
            theMain.setText("Sorry no address!");
        }

    }

}

